export class InventoryManager {
    constructor(canvas, ctx) {
        this.canvas = canvas;
        this.ctx = ctx;
        this.inventory = [];
        this.currentChest = null;
        this.isOpen = false;

        // Настройки окон
        this.winW = 400;
        this.winH = 400;
        this.gap = 40;
        this.startY = (this.canvas.height - this.winH) / 2;

        // Состояние Drag-and-Drop
        this.draggedItem = null;
        this.dragSource = null;
        this.mouseX = 0;
        this.mouseY = 0;

        this.initEvents();
    }

    initEvents() {
        this.canvas.addEventListener("mousedown", (e) => this.handleMouseDown(e.clientX, e.clientY));
        this.canvas.addEventListener("mousemove", (e) => {
            this.mouseX = e.clientX;
            this.mouseY = e.clientY;
        });
        window.addEventListener("mouseup", (e) => this.handleMouseUp(e.clientX, e.clientY));
    }

    handleMouseDown(mx, my) {
        if (!this.isOpen) return;

        const { invX, chestX } = this.getWindowsX();

        // Клик по инвентарю
        if (mx > invX && mx < invX + this.winW && my > this.startY && my < this.startY + this.winH) {
            const itemIdx = Math.floor((my - (this.startY + 80)) / 40);
            if (this.inventory[itemIdx]) {
                this.draggedItem = this.inventory.splice(itemIdx, 1)[0];
                this.dragSource = 'inventory';
            }
        }
        // Клик по сундуку
        else if (this.currentChest && mx > chestX && mx < chestX + this.winW && my > this.startY && my < this.startY + this.winH) {
            const itemIdx = Math.floor((my - (this.startY + 80)) / 40);
            if (this.currentChest.items[itemIdx]) {
                this.draggedItem = this.currentChest.items.splice(itemIdx, 1)[0];
                this.dragSource = 'chest';
            }
        }
    }

    handleMouseUp(mx, my) {
        if (!this.draggedItem) return;

        const { invX, chestX } = this.getWindowsX();

        if (mx > invX && mx < invX + this.winW && my > this.startY && my < this.startY + this.winH) {
            this.inventory.push(this.draggedItem);
        } 
        else if (this.currentChest && mx > chestX && mx < chestX + this.winW && my > this.startY && my < this.startY + this.winH) {
            this.currentChest.items.push(this.draggedItem);
        } 
        else {
            // Возврат
            if (this.dragSource === 'inventory') this.inventory.push(this.draggedItem);
            else this.currentChest.items.push(this.draggedItem);
        }
        this.draggedItem = null;
        this.dragSource = null;
    }

    getWindowsX() {
        const invX = this.currentChest ? (this.canvas.width / 2 - this.winW - this.gap / 2) : (this.canvas.width - this.winW) / 2;
        const chestX = this.canvas.width / 2 + this.gap / 2;
        return { invX, chestX };
    }

    draw() {
        if (!this.isOpen && !this.currentChest) return;

        // Затемнение фона
        this.ctx.fillStyle = "rgba(0,0,0,0.7)";
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        const { invX, chestX } = this.getWindowsX();

        // Рисуем инвентарь
        this.drawUIWindow("Инвентарь", this.inventory, invX, this.startY);

        // Рисуем сундук, если он открыт
        if (this.currentChest) {
            this.drawUIWindow("Сундук", this.currentChest.items, chestX, this.startY);
        }

        // Рисуем предмет в руке
        if (this.draggedItem) {
            this.ctx.fillStyle = "yellow";
            this.ctx.font = "bold 20px Arial";
            this.ctx.fillText(this.draggedItem, this.mouseX - 20, this.mouseY);
        }
    }

    drawUIWindow(title, items, x, y) {
        this.ctx.fillStyle = "#333";
        this.ctx.strokeStyle = "white";
        this.ctx.lineWidth = 3;
        this.ctx.fillRect(x, y, this.winW, this.winH);
        this.ctx.strokeRect(x, y, this.winW, this.winH);

        this.ctx.fillStyle = "#ffcc00";
        this.ctx.font = "bold 22px Arial";
        this.ctx.fillText(title, x + 20, y + 45);

        this.ctx.font = "18px Arial";
        this.ctx.fillStyle = "white";
        if (items.length === 0) {
            this.ctx.fillStyle = "#666";
            this.ctx.fillText("Пусто", x + 20, y + 100);
        } else {
            items.forEach((item, i) => {
                this.ctx.fillText(`${i + 1}. ${item}`, x + 25, y + 100 + (i * 40));
            });
        }
    }
}