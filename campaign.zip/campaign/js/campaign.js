import { CMlevels } from './maps.js';
import { CampaignCamera } from './camera.js';
import { Movement } from './movement.js';

const canvas = document.getElementById("campaign");
const ctx = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const tileS = 100;  ////////////////// ROZMIAR KLATKI ////////////////////

let currentLevelIndex = 0;
let levelData = CMlevels[currentLevelIndex];
let map = levelData.grid;

let player = { x: 0, y: 0, pixelX: 0, pixelY: 0 };
let movement = new Movement(player, map, tileS);

let camera = new CampaignCamera(canvas.width, canvas.height, map[0].length * tileS, map.length * tileS);

let isTeleporting = false;

////////////////////// СИСТЕМА ИНВЕНТАРЯ И СУНДУКОВ //////////////////////
let inventory = []; // Инвентарь игрока
let currentChest = null; // Какой сундук сейчас открыт
let isInventoryOpen = false; // Открыт ли личный инвентарь

// Нажатие клавиш
window.addEventListener("keydown", (e) => {
    const key = e.key.toLowerCase();
    
    // Взаимодействие (E)
    if (key === "e" || key === "у") {
        if (currentChest) {
            currentChest = null;
        } else if (!isInventoryOpen) {
            checkChestInteraction();
        }
    }

    // Инвентарь (F)
    if (key === "f" || key === "а") {
        if (!currentChest) { // Не открывать инвентарь, если смотрим в сундук
            isInventoryOpen = !isInventoryOpen;
        }
    }
});

// Клик мышкой
canvas.addEventListener("click", (e) => {
    if (currentChest) {
        handleChestClick(e.clientX, e.clientY);
    }
});

function checkChestInteraction() {
    let gridX = Math.floor((player.pixelX + tileS / 2) / tileS);
    let gridY = Math.floor((player.pixelY + tileS / 2) / tileS);

    if (map[gridY] && map[gridY][gridX] === 2) {
        const chestKey = `${gridX},${gridY}`;
        if (levelData.chests && levelData.chests[chestKey]) {
            currentChest = {
                key: chestKey,
                items: levelData.chests[chestKey]
            };
        }
    }
}

function handleChestClick(mx, my) {
    const winW = 400;
    const winH = 300;
    const startX = (canvas.width - winW) / 2;
    const startY = (canvas.height - winH) / 2;

    if (mx > startX && mx < startX + winW && my > startY && my < startY + winH) {
        if (currentChest.items.length > 0) {
            const item = currentChest.items.pop();
            inventory.push(item);
        }
    }
}
//////////////////////////////////////////////////////////////////////////

function initLevel(index, spawnX = null, spawnY = null) {
    currentLevelIndex = index;
    levelData = CMlevels[currentLevelIndex];
    map = levelData.grid;

    if (spawnX !== null && spawnY !== null) {
        player.pixelX = spawnX * tileS;
        player.pixelY = spawnY * tileS;
    } else {
        for (let y = 0; y < map.length; y++) {
            for (let x = 0; x < map[y].length; x++) {
                if (map[y][x] === 3) {
                    player.pixelX = x * tileS;
                    player.pixelY = y * tileS;
                }
            }
        }
    }
    
    movement.map = map;
    camera = new CampaignCamera(canvas.width, canvas.height, map[0].length * tileS, map.length * tileS);
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Блокируем движение, если открыт сундук или инвентарь
    if (!currentChest && !isInventoryOpen) {
        movement.update();
    }
    
    camera.update(player.pixelX, player.pixelY);
    
    let gridX = Math.floor((player.pixelX + tileS / 2) / tileS);
    let gridY = Math.floor((player.pixelY + tileS / 2) / tileS);
    
    if (map[gridY] && map[gridY][gridX] >= 4 && !isTeleporting) {
        const portal = levelData.portals[map[gridY][gridX]];
        if (portal) {
            isTeleporting = true;
            initLevel(portal.targetLevel, portal.targetX, portal.targetY);
            setTimeout(() => { isTeleporting = false; }, 500);
            requestAnimationFrame(draw);
            return; 
        }
    }

    ctx.save();
    ctx.translate(Math.floor(-camera.x), Math.floor(-camera.y));

    for (let y = 0; y < map.length; y++) {
        for (let x = 0; x < map[y].length; x++) {
            if (map[y][x] === 1) {
                ctx.fillStyle = "#333";
            } else if (map[y][x] === 2) {
                ctx.fillStyle = "orange";
            } else if (map[y][x] >= 4) {
                ctx.fillStyle = "blue";
            } else {
                ctx.fillStyle = "#eee";
            }
            ctx.fillRect(x * tileS, y * tileS, tileS, tileS);
        }
    }

    ctx.fillStyle = "red";
    const m = movement.margin; 
    ctx.fillRect(
        Math.floor(player.pixelX) + m, 
        Math.floor(player.pixelY) + m, 
        tileS - m * 2, 
        tileS - m * 2
    );

    ctx.restore();

    // РИСОВАНИЕ ОКНА СУНДУКА
    if (currentChest) {
        drawUIWindow("Сундук (Кликни, чтобы забрать)", currentChest.items, "Нажми 'E', чтобы закрыть");
    }

    // РИСОВАНИЕ ВАШЕГО ИНВЕНТАРЯ
    if (isInventoryOpen) {
        drawUIWindow("Твой Инвентарь", inventory, "Нажми 'F', чтобы закрыть");
    }

    requestAnimationFrame(draw);
}

// Универсальная функция для отрисовки окон
function drawUIWindow(title, items, footer) {
    ctx.fillStyle = "rgba(0,0,0,0.6)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const winW = 450;
    const winH = 350;
    const x = (canvas.width - winW) / 2;
    const y = (canvas.height - winH) / 2;

    ctx.fillStyle = "#444";
    ctx.strokeStyle = "white";
    ctx.lineWidth = 5;
    ctx.fillRect(x, y, winW, winH);
    ctx.strokeRect(x, y, winW, winH);

    ctx.fillStyle = "white";
    ctx.font = "bold 22px Arial";
    ctx.fillText(title, x + 30, y + 50);

    ctx.font = "18px Arial";
    if (items.length === 0) {
        ctx.fillText("Здесь пока ничего нет...", x + 30, y + 100);
    } else {
        items.forEach((item, i) => {
            ctx.fillText(`${i + 1}. ${item}`, x + 30, y + 100 + (i * 30));
        });
    }

    ctx.font = "italic 16px Arial";
    ctx.fillStyle = "#ccc";
    ctx.fillText(footer, x + 30, y + winH - 25);
}

initLevel(0);
draw();